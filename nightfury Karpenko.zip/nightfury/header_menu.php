<?php
echo '<nav class="group">
					<ul class="menu navigation">
						<li><a href="index.php"><i class="fa fa-shield fa-2x"></i> Domov</a></li>
						<li><a href="portfolio.php"><i class="fa fa-leaf fa-2x"></i> Portfolio</a></li>
						<li><a href="about.php"><i class="fa fa-bolt fa-2x"></i> O nás</a></li>
						<li><a href="contact.php"><i class="fa fa-trophy fa-2x"></i> Kontakt</a></li>
					</ul>
				</nav>
			</div>
		</div>';
        ?>