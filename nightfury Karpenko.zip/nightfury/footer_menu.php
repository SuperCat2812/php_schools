<?php
echo '<ul class="menu nav-footer">
				<li><a href="index.php">Domov</a></li>
				<li><a href="portfolio.php">Portfólio</a></li>
				<li><a href="about.php">O nás</a></li>
				<li><a href="contact.php">Kontakt</a></li>
			</ul>';
            ?>